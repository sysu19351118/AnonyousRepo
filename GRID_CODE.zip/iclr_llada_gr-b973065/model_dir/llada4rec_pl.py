
import sys

# sys.path.append('/home/tangzixuan.8/Generative_recall/LLaDA_weight')
import torch
import numpy as np
import torch.nn.functional as F
from transformers import AutoConfig
import pdb
from transformers import AutoTokenizer, AutoModel
import copy
import os
from LLaDA_weight.modeling_llada import LLaDAModel
from LLaDA_weight.configuration_llada import LLaDAConfig
import pickle
import yaml
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from typing import Optional, Dict, Any, List
import torchmetrics

from model_dir.dual_tower_model import DualTowerModel
from transformers import AutoConfig, AutoModel
import math
def ndcg_at_k_single_positive( rank, k):
    """
    计算只有一个正样本时的NDCG@K
    
    参数:
    rank (int): 正样本在推荐列表中的位置（从1开始计数）
    k (int): 要考虑的top K个项目
    
    返回:
    float: NDCG@K 值，范围 [0, 1]
    """
    # 如果正样本不在前K个中，NDCG@K为0
    if rank > k or rank < 1:
        return 0.0
    
    # 计算DCG@K：只有一个相关项，位置在rank处
    dcg = 1.0 / math.log2(rank + 1)  # 使用log2(rank+1)
    
    # 计算IDCG@K：理想情况是正样本排在第一位
    idcg = 1.0 / math.log2(1 + 1)  # 即 1.0
    
    return dcg / idcg


class LLaDA4Rec(pl.LightningModule):
    def __init__(
        self,
        config,
    ):
        """
        初始化Lightning模型
        
        Args:
            input_dim: 输入维度
            hidden_dim: 隐藏层维度
            output_dim: 输出维度
            learning_rate: 学习率
            dropout_rate: dropout比率
        """
        super().__init__()
        device = 'cuda'
        self.config = config
        llada_config = AutoConfig.from_pretrained(config['model']['config_path'])
        self.end = config['model']['t_end']
        self.beg = config['model']['t_beg']
        self.sid_lenth = config['model']['sid_lenth']
        # self.llada_decoder = LLaDAModel(llada_config)
        self.llada_decoder = AutoModel.from_config(llada_config, torch_dtype=torch.bfloat16)
        self.mask_token = config['model']['special_token']['MASK']
        self.total_num = 0
        self.hitnum1 = 0
        self.hitnum5 = 0
        self.hitnum10 = 0
        self.hitnum15 = 0
        self.hitnum20 = 0
        self.ndcg1 = 0.0
        self.ndcg5 = 0.0
        self.ndcg10 = 0.0
        self.ndcg15 = 0.0
        self.ndcg20 = 0.0

    def forward(self, user_repr, item_token):
        # user -> user tower -> user_repr

        user_repr = self.user_respr_mlp(user_repr).unsqueeze(dim=1)
        user_repr = user_repr.to(dtype=torch.bfloat16)  # 或者模型使用的数据类型
        import time
        t1 = time.time()
        result = self.llada_decoder(user_repr, item_token)
        print(time.time() - t1)
        
        pass

    def change_word(self, input_ids, mask_or_change_indices):
        
        return input_ids, masked_indices
    
    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=self.config['train']['learning_rate'],
            weight_decay=self.config['train']['weight_decay'],
            eps=1e-8
        )
        
        # 带重启的余弦退火调度器
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=self.config['train'].get('restart_epochs', 10),  # 第一次重启的周期
            T_mult=self.config['train'].get('restart_multiplier', 2),  # 重启周期倍增因子
            eta_min=self.config['train'].get('min_learning_rate', 1e-6)
        )
        
        return {
            'optimizer': optimizer,
            'lr_scheduler': {
                'scheduler': scheduler,
                'interval': 'step',   # 每个训练step后更新（更适合WarmRestarts）
                'frequency': 1,
            }
        }

    def add_mask(self, batch, eps=1e-6, mode = 'train'):

        batch_size, sqlen = batch['hist_token'].shape
        if mode == "test":
            t = torch.ones(batch_size, device= batch['hist_token'].device)*0.5
        elif mode == 'train':
            t = torch.rand(batch_size, device= batch['hist_token'].device)
            width = self.end - self.beg
            t = t * width + self.beg
        else:
            print("这种mode不对，来检查下")
            sys.exit()

        p_mask = (1 - eps) * t + eps
        p_mask = p_mask[:, None].repeat(1, sqlen)

        # 记录前面prompt部分的长度，防止对其进行加噪
        prompt_lenth = (batch['hist_idx_mask'].sum(dim=1)-1) * (self.sid_lenth + 1)
        end_token_beg_index = prompt_lenth + self.sid_lenth
        # 生成一个0～1均匀分布的，跟batch['hist_token']形状一样的矩阵，如果小于t就对其进行mask
        change2mask_indices = torch.rand(
            (batch['hist_token'].shape[0], batch['hist_token'].shape[1]), 
            device= batch['hist_idx_mask'].device
        ) < p_mask
        mask_tensor = torch.where(change2mask_indices, self.mask_token, batch['hist_token']) 

        # 需要把prompt和mask 部分的 token 捞回来
        # prompt部分 
        bs_sqlen_tensor = torch.arange(
            batch['hist_token'].shape[1] # 生成一个0～sqlen的indices
        ).unsqueeze(
            dim=0  #在第0维度展平，方便repeat
        ).repeat(
            batch_size, 1  # repeat 成batch[hist_idx_mask]相同的形状
        ).to(prompt_lenth.device) 
        prompt_mask = bs_sqlen_tensor < prompt_lenth.unsqueeze(dim=1)  # 小于pl的表示prompt部分，需要我们捞回来
        # 用torch where 捞回来
        mask_tensor = torch.where(prompt_mask, batch['hist_token'], mask_tensor)
        # 把pad部分同样捞回来
        end_token_beg_index = prompt_lenth + self.sid_lenth
        end_mask = bs_sqlen_tensor > end_token_beg_index.unsqueeze(dim=1)
        mask_tensor = torch.where(end_mask, batch['hist_token'], mask_tensor)
        mask_indices = ~(mask_tensor ==  batch['hist_token'])

        return mask_tensor, p_mask, mask_indices


    def compute_loss(self, logits, gt, p_mask, mask):
        token_loss = F.cross_entropy(logits[mask], gt[mask], reduction='none') / p_mask[mask]
        ce_loss = torch.sum(token_loss) / (gt.shape[0] +1e-6)
        return ce_loss
    
    def training_step(self, batch, batch_idx, eps = 1e-6):
        mask_tokens, p_mask, mask_indices = self.add_mask(batch)
        result = self.llada_decoder(mask_tokens).logits
        loss = self.compute_loss(result, batch['hist_token'], p_mask, mask_indices)
        pred = result.argmax(dim=-1)[mask_indices]
        pred = torch.clamp_max(pred, 30)
        self.log('train_loss', loss, prog_bar=True)
        self.log('pred', pred.float().mean(), prog_bar=True)
        return loss




    def validation_step(self, batch, batch_idx):
        # user_repr = self.user_encoder.encode_user(batch)
        # user_repr = self.user_respr_mlp(user_repr).unsqueeze(dim=1)
        # mask_tokens, p_mask, mask_indices = self.add_mask(batch, mode = 'test')
        # result = self.llada_decoder(user_repr, mask_tokens).logits[:, 1:, :]
        # pred = result.argmax(dim=-1)[mask_indices]
        # gt = batch['hist_token'][mask_indices]
        pass
    
    # def test_step(self, batch, batch_idx):
    #     user_repr = self.user_encoder.encode_user(batch)
    #     user_repr = self.user_respr_mlp(user_repr).unsqueeze(dim=1)
    #     mask_tokens, p_mask, mask_indices = self.add_mask(batch, mode = 'test')
    #     result = self.llada_decoder(user_repr, mask_tokens).logits[:, 1:, :] # 这里这个1 是为了把user位置的token排除
    #     pred = result.argmax(dim=-1)[mask_indices]
    #     gt = batch['hist_token'][mask_indices]
    #     loss = self.compute_loss(result, batch['hist_token'], p_mask, mask_indices)

    #     # 逐个样本处理
    #     bs = batch['hist_token'].shape[0]
    #     for b in range(bs):
    #         for iters in range(self.config['model']['sid_lenth']+1):
    #             logits = self.llada_decoder(user_repr[b:b+1], mask_tokens[b:b+1]).logits[:, 1:, :]
    #             soft_max_logits = F.softmax(logits, dim=-1)
    #             top1_logits = soft_max_logits.topk(1,dim=-1)
    #             mask_place_logits = torch.where(mask_indices[b:b+1], top1_logits.values.squeeze(dim=2) ,1e-10)
    #             demask_indices = mask_place_logits.topk(1).indices
    #             mask_tokens[b,demask_indices] = top1_logits.indices.squeeze()[demask_indices.squeeze()]
    #             mask_indices[b,demask_indices] = False
    #     self.hitnum += ((mask_tokens == batch['hist_token']).sum(dim=-1) >= (batch['hist_token'].shape[1]-1)).sum()
    #     self.total_num += bs
    #     print(self.hitnum / self.total_num)
        
    def test_step(self, batch, batch_idx, ):
        beam_width=5
        bs = batch['hist_token'].shape[0]
        mask_tokens, p_mask, mask_indices = self.add_mask(batch, mode='test')
        mask_indices_copy = mask_indices.clone()
        
        result = self.llada_decoder( mask_tokens).logits
        # pred = result.argmax(dim=-1)[mask_indices]
        # gt = batch['hist_token'][mask_indices].reshape(bs, -1)
        # loss = self.compute_loss(result, batch['hist_token'], p_mask, mask_indices)
        for b in range(bs):

            term_gt = batch['hist_token'][b][mask_indices[b]].tolist()
            # term_gt = gt[b].tolist()
            # 初始化beam
            beams = [{
                'tokens': mask_tokens[b:b+1].clone(),
                'mask_indices': mask_indices[b:b+1].clone(),
                'score': 0.0
            }]
            count = 0
            new_beams = []
            while any(beam['mask_indices'].any() for beam in beams):
                pdb.set_trace()
                for beam in beams:
                    if not beam['mask_indices'].any():
                        new_beams.append(beam)
                        continue
                    
                    # 获取预测
                    with torch.no_grad():
                        logits = self.llada_decoder(
                            beam['tokens']
                        ).logits
                    
                    probs = F.softmax(logits, dim=-1)
                    
                    # 找到最置信的mask位置（概率最高的位置）
                    mask_positions = torch.where(beam['mask_indices'][0])[0]
                    
                    # 获取每个mask位置的最大概率
                    max_probs = []
                    for pos in mask_positions:
                        pos_max_prob = probs[0, pos, :].max()
                        max_probs.append(pos_max_prob.item())
                    
                    # 选择概率最高的mask位置
                    if max_probs:
                        best_pos_idx = torch.argmax(torch.tensor(max_probs))
                        best_pos = mask_positions[best_pos_idx]
                        
                        # 对这一个位置生成beam_width个候选
                        pos_probs = probs[0, best_pos, :]
                        topk_probs, topk_indices = pos_probs.topk(beam_width)
                        
                        for i in range(beam_width):
                            new_tokens = beam['tokens'].clone()
                            new_mask_indices = beam['mask_indices'].clone()
                            
                            new_tokens[0, best_pos] = topk_indices[i]
                            new_mask_indices[0, best_pos] = False
                            
                            new_score = beam['score'] + torch.log(topk_probs[i]).item()
                            
                            new_beams.append({
                                'tokens': new_tokens,
                                'mask_indices': new_mask_indices,
                                'score': new_score
                            })
                    else:
                        new_beams.append(beam)
                
                # 选择score最高的top-k beams
                new_beams.sort(key=lambda x: x['score'], reverse=True)
                beams = new_beams[:beam_width]
            
            sid_list = []
            if len(new_beams) != 0:
                for beam in new_beams:
                    sid_list.append(beam['tokens'][mask_indices_copy[b].unsqueeze(dim=0)].tolist())

                # 使用最佳beam的结果
                best_beam = beams[0]
                mask_tokens[b] = best_beam['tokens'][0]
                mask_indices[b] = best_beam['mask_indices'][0]

                self.hitnum1 += int(term_gt in sid_list[:1])
                self.hitnum5 += int(term_gt in sid_list[:5])
                self.hitnum10 += int(term_gt in sid_list[:10])
                self.hitnum15 += int(term_gt in sid_list[:15])
                self.hitnum20 += int(term_gt in sid_list[:20])
                self.total_num += 1

                if term_gt in sid_list:
                    rank = sid_list.index(term_gt) + 1  # 位置从1开始计数
                else:
                    rank = float("inf") #
                self.ndcg1 += ndcg_at_k_single_positive(rank, 1)
                self.ndcg5 += ndcg_at_k_single_positive(rank, 5)
                self.ndcg10 += ndcg_at_k_single_positive(rank, 10)
                self.ndcg15 += ndcg_at_k_single_positive(rank, 15)
                self.ndcg20 += ndcg_at_k_single_positive(rank, 20)

            else:
                continue
            print(self.total_num)
            print(f"hit@1:{self.hitnum1/self.total_num}; hit@5:{self.hitnum5/self.total_num}; hit@10:{self.hitnum10/self.total_num}; hit@15:{self.hitnum15/self.total_num}; hit@20:{self.hitnum20/self.total_num};")
            print(f"ndcg@1:{self.ndcg1/self.total_num}; ndcg@5:{self.ndcg5/self.total_num}; ndcg@10:{self.ndcg10/self.total_num}; ndcg@15:{self.ndcg15/self.total_num}; ndcg@20:{self.ndcg20/self.total_num};")
            
        # return loss
    
    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        pass
    
    def on_train_epoch_end(self):
        pass
    
    def on_validation_epoch_end(self):
        pass




def main(config):
    model = LLaDA4Rec(config).cuda()
    user = torch.zeros((16, 64)).cuda().float()
    user_his = torch.zeros((16, 300)).cuda().int()
    model(user, user_his)
    


def load_config(config_path):
    """加载YAML配置文件"""
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config
    # amp_bf16
if __name__ == "__main__":
    config_file = '/home/tangzixuan.8/Generative_recall/generative_recall_rank/config/config.yaml'
    config = load_config(config_file)
    main(config)