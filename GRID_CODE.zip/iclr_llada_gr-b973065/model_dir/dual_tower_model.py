import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from typing import Dict, List, Tuple, Optional, Any
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
import yaml
import json
import pandas as pd
import numpy as np
from collections import defaultdict
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import random
from transformers import BertTokenizer, BertModel
import pdb
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR


class DualTowerModel(pl.LightningModule):
    def __init__(
        self,
        config: Dict[str, Any],
    ):
        super().__init__()
        self.save_hyperparameters()
        self.config = config
        
        self.neg_sample_num = config['train']['neg_sample_num']


        ## 用户id embedding
        self.user_embedding = nn.Embedding(config['model']['user_tower']['user_num'] , config['model']['user_tower']['user_embedding_dim'])     

        ## 商品id embedding
        self.item_embedding = nn.Embedding(config['model']['item_tower']['item_num'] , config['model']['item_tower']['item_embedding_dim'])
        self.user_mlp = nn.Sequential(
            nn.Linear(config['model']['user_tower']['user_embedding_dim'] + config['model']['item_tower']['item_embedding_dim'], 128),
            nn.ReLU(),
            nn.Linear(128, config['model']['user_tower']['repr_dim']),
        )
        # 价格
        self.price_embedding = nn.Embedding(20 , 16)
        # 品牌
        self.brand_embedding = nn.Embedding(config['model']['item_tower']['brand_num'] , config['model']['item_tower']['brand_embedding_dim'])

        # 预训练的BERT模型用于文本特征提取
        self.bert_model = BertModel.from_pretrained(config['model']['bert_pretrain'])
        self.text_mlp = nn.Sequential(
            nn.Linear(768*2, 256),
            nn.ReLU(),
            nn.Linear(256, 64),
        )
        self.item_mlp = nn.Sequential(
            nn.Linear(config['model']['item_tower']['item_embedding_dim'] + config['model']['item_tower']['brand_embedding_dim'] + 16 + 64, 128),
            nn.ReLU(),
            nn.Linear(128, config['model']['item_tower']['repr_dim']),
        )
        self.hit_nums = []

    
    
    def forward_left(self, x: torch.Tensor) -> torch.Tensor:
        """前向传播左侧塔"""
        return self.left_tower(x)

    def load_sku_emb(self, emb_path):
        self.sku_emb = F.normalize(torch.tensor(np.load(emb_path)).float()).cuda()
        
    
    
    def forward_right(self, x: torch.Tensor) -> torch.Tensor:
        """前向传播右侧塔"""
        return self.right_tower(x)
    
    def forward(self, batch):
        """前向传播双塔"""
        left_embedding = self.forward_left(left_input)
        right_embedding = self.forward_right(right_input)
        return left_embedding, right_embedding

    def encode_user(self, user_feature: Dict[str, torch.Tensor]) -> torch.Tensor:
        """编码用户特征"""
        user_idx = user_feature['user_idx']
        user_emb = self.user_embedding(user_idx)
        
        hist_idx = user_feature['hist_idx']
        hist_idx_mask = user_feature['hist_idx_mask']
        hist_emb = self.item_embedding(hist_idx % self.config['model']['item_tower']['item_num'])  # [batch_size, seq_len, emb_dim]
        mask = hist_idx_mask.unsqueeze(-1)  # [batch_size, seq_len, 1]
        masked_hist_emb = hist_emb * mask
        valid_lengths = mask.sum(dim=1)  # [batch_size, 1]
        hist_emb = masked_hist_emb.sum(dim=1) / valid_lengths.clamp(min=1)  # [batch_size, emb_dim]
        user_repr = torch.cat([user_emb, hist_emb], dim=-1)
        user_emb = self.user_mlp(user_repr)
        return user_emb

    def encode_item(self, item_feature: Dict[str, torch.Tensor]) -> torch.Tensor:
        """编码商品特征"""
        # 商品id 表示
        item_idx = item_feature['item_idx']
        item_idx_repr = self.item_embedding(item_idx % self.config['model']['item_tower']['item_num'])

        # 商品文本表示
        title_repr = self.bert_model(input_ids=item_feature['title_input_ids'], attention_mask=item_feature['title_attention_mask']).pooler_output
        description_repr = self.bert_model(input_ids=item_feature['description_input_ids'], attention_mask=item_feature['description_attention_mask']).pooler_output
        text_repr = torch.cat([title_repr, description_repr], dim=-1)
        text_repr = self.text_mlp(text_repr)

        # 商品品牌表示
        brand_idx = item_feature['brand_idx']
        brand_idx_repr = self.brand_embedding(brand_idx)
        # 商品价格表示
        price = item_feature['price']
        price = torch.clamp(price, max=19, min=0)
        price_repr = self.price_embedding(price)
        item_repr = torch.cat([item_idx_repr, brand_idx_repr, price_repr, text_repr], dim=-1)
        item_emb = self.item_mlp(item_repr)
        return item_emb

    def rename(self, dict_):
        new_dict = {}
        for k, v in dict_.items():
            new_dict[k.replace('pos_','').replace('neg_','')] = v
        return new_dict
    

    def compute_loss(self, user_repr: torch.Tensor, positive_repr: torch.Tensor, negative_repr: torch.Tensor) -> torch.Tensor:
        temperature = 0.05
        # 归一化所有表示
        user_norm = F.normalize(user_repr, dim=-1)  # [batch_size, dim]
        pos_norm = F.normalize(positive_repr, dim=-1)  # [batch_size, dim]
        # 处理负样本表示
        batch_size = user_repr.size(0)
        neg_norm = F.normalize(negative_repr, dim=-1)
        neg_norm = neg_norm.view(batch_size, self.config['train']['neg_sample_num'], -1)  # [batch_size, neg_num, dim]
        # 计算正样本相似度 [batch_size]
        pos_scores = (user_norm * pos_norm).sum(dim=-1) / temperature
        # 计算负样本相似度 [batch_size, neg_num]
        neg_scores = torch.bmm(user_norm.unsqueeze(1), neg_norm.transpose(1, 2)).squeeze(1) / temperature
        # 拼接logits [batch_size, 1 + neg_num * bs]
        logits = torch.cat([pos_scores.unsqueeze(1), neg_scores], dim=1)
        # 标签：正样本总是在第一个位置
        labels = torch.zeros(batch_size, dtype=torch.long, device=logits.device)
        # 计算InfoNCE损失
        nce_loss = F.cross_entropy(logits, labels)
        total_loss = nce_loss 
        # 可选：计算一些统计信息
        with torch.no_grad():
            batch_similarity = logits.mean(dim=0) * temperature
            pos_neg_ratio = (pos_scores.exp().mean() / neg_scores.exp().mean()).item()
        
        return total_loss, nce_loss, batch_similarity

    
    def training_step(self, batch, batch_idx: int) -> torch.Tensor:
        """训练步骤"""
        
        user_feature , positive, negative = batch
        if user_feature['user_idx'].shape[0] != self.config['train']['batch_size']:
            print("此batch数据有问题，跳过")
            return None 
        positive = self.rename(positive)
        negative = self.rename(negative)
        positive_repr = self.encode_item(positive)
        negative_repr = self.encode_item(negative)
        user_repr = self.encode_user(user_feature)
        loss, info_loss, sim = self.compute_loss(user_repr, positive_repr, negative_repr)
        self.log('train_loss', loss, prog_bar=True, logger=True)
        self.log('info_loss', info_loss, prog_bar=True, logger=True)
        self.log('pos_sim', sim[0], prog_bar=True, logger=True)
        self.log('neg_sim', (sim[1]+sim[2])/2, prog_bar=True, logger=True)
        return loss
    
    def validation_step(self, batch, batch_idx: int) -> Dict[str, torch.Tensor]:
        pass

    
    def test_step(self, batch: Tuple[torch.Tensor, torch.Tensor, torch.Tensor], batch_idx: int) -> Dict[str, torch.Tensor]:
        """测试步骤"""
        k=100
        freq_k = 20
        usr, pos, _ = batch
        usr_repr = F.normalize(self.encode_user(usr))
        similarity = usr_repr @ self.sku_emb.transpose(-1,-2) # shape bs, items_num
        topk_indices = torch.topk(similarity, k=k, dim=1).indices
        pos_item_idx = pos['pos_item_idx']

        # pos['item_ids'][0][pos['pos_item_idx'].cpu().numpy()] 
        
        # 找到正样本在topk中的位置
        pos_expanded = pos_item_idx.unsqueeze(1)
        pos_in_topk_mask = (topk_indices == pos_expanded)
        
        # 获取位置索引 (如果在topk中)
        pos_rank = torch.where(pos_in_topk_mask.any(dim=1),
                            pos_in_topk_mask.int().argmax(dim=1) + 1,  # +1因为排名从1开始
                            torch.tensor(0, device=topk_indices.device))  # 0表示不在topk中

        # 测试
        freq = np.load('/mnt/data2/zzixuantang/ICLR/data/amazon-beauty/cache/freq.npy')
        pos_freq = freq[pos_item_idx.cpu()] # 正样本频率
        pos_sim = (self.sku_emb[pos_item_idx]*usr_repr).sum(dim=-1)  # 正样本相似度

        topk_sim = torch.topk(similarity, k=k, dim=1).values
        topk_freq = freq[torch.topk(similarity, k=k, dim=1).indices.cpu()]

        pos_rank_filltered = pos_rank[pos_freq >= freq_k] # https://jmcauley.ucsd.edu/data/amazon/amazon_readme.txt
        
        in_topk = pos_in_topk_mask.any(dim=1)
        in_topk = in_topk[pos_freq >= freq_k]
        
        hit_ratio = in_topk.float().mean()
        for hit in in_topk:
            if hit:
                self.hit_nums.append(1)
            else:
                self.hit_nums.append(0)
        print(sum(self.hit_nums)/len(self.hit_nums), len(self.hit_nums))
        
    

    def configure_optimizers(self) -> Dict[str, Any]:
        """配置优化器和余弦退火学习率调度器"""
        optimizer = optim.Adam(self.parameters(), lr=self.config['train']['learning_rate'])
        
        # 使用余弦退火调度器
        scheduler = CosineAnnealingLR(
            optimizer, 
            T_max=self.trainer.max_epochs,  # 余弦周期的长度（通常设为总训练轮次）
            eta_min=0  # 最小学习率，默认为0
        )
        
        return {
            'optimizer': optimizer,
            'lr_scheduler': {
                'scheduler': scheduler,
                'interval': 'epoch',  # 每个epoch后更新
                'frequency': 1  # 每个epoch都更新
            }
        }
        
    def get_similarity(self, left_emb: torch.Tensor, right_emb: torch.Tensor) -> torch.Tensor:
        """计算两个嵌入向量的相似度"""
        return F.cosine_similarity(left_emb, right_emb, dim=-1)
    
    def predict_step(self, batch: Tuple[torch.Tensor, torch.Tensor, torch.Tensor], batch_idx: int) -> Dict[str, torch.Tensor]:
        itemembedding = self.encode_item(batch)
        item_names = batch['item_names'][batch['item_idx'].cpu()]
        return itemembedding, item_names