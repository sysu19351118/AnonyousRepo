import torch
import numpy as np
import torch.nn.functional as F

import pdb
from transformers import AutoTokenizer, AutoModel
import copy
import os

import pickle

def save_list_to_pickle(data_list, file_path):
    """
    将list保存到pkl文件
    
    参数:
    data_list: 要保存的列表
    file_path: 保存的文件路径，如 'data.pkl'
    """
    try:
        with open(file_path, 'wb') as f:  # 'wb' 表示以二进制写入模式打开
            pickle.dump(data_list, f)
        print(f"列表已成功保存到 {file_path}")
        return True
    except Exception as e:
        print(f"保存失败: {str(e)}")
        return False


def rename_folder_simple(folder_A, folder_B):
    """
    使用os.rename重命名文件夹
    """
    try:
        os.rename(folder_A, folder_B)
        print(f"成功重命名: {folder_A} -> {folder_B}")
        return True
    except FileNotFoundError:
        print(f"错误：文件夹 '{folder_A}' 不存在")
        return False
    except FileExistsError:
        print(f"错误：目标文件夹 '{folder_B}' 已存在")
        return False
    except Exception as e:
        print(f"错误: {str(e)}")
        return False

def add_gumbel_noise(logits, temperature):
    '''
    The Gumbel max is a method for sampling categorical distributions.
    According to arXiv:2409.02908, for MDM, low-precision Gumbel Max improves perplexity score but reduces generation quality.
    Thus, we use float64.
    '''
    if temperature == 0:
        return logits
    logits = logits.to(torch.float64)
    noise = torch.rand_like(logits, dtype=torch.float64)
    gumbel_noise = (- torch.log(noise)) ** temperature
    return logits.exp() / gumbel_noise


def get_num_transfer_tokens(mask_index, steps):
    '''
    In the reverse process, the interval [0, 1] is uniformly discretized into steps intervals.
    Furthermore, because LLaDA employs a linear noise schedule (as defined in Eq. (8)),
    the expected number of tokens transitioned at each step should be consistent.

    This function is designed to precompute the number of tokens that need to be transitioned at each step.
    '''
    mask_num = mask_index.sum(dim=1, keepdim=True)

    base = mask_num // steps
    remainder = mask_num % steps

    num_transfer_tokens = torch.zeros(mask_num.size(0), steps, device=mask_index.device, dtype=torch.int64) + base

    for i in range(mask_num.size(0)):
        num_transfer_tokens[i, :remainder[i]] += 1

    return num_transfer_tokens


@ torch.no_grad()
def generate(model, prompt, steps=128, gen_length=128, block_length=128, post_step_num=32,  temperature=0.,
             cfg_scale=0., remasking='low_confidence', mask_id=126336, tokenizer = None):
    '''
    Args:
        model: Mask predictor.
        prompt: A tensor of shape (1, L).
        steps: Sampling steps, less than or equal to gen_length.
        gen_length: Generated answer length.
        block_length: Block length, less than or equal to gen_length. If less than gen_length, it means using semi_autoregressive remasking.
        temperature: Categorical distribution sampling temperature.
        cfg_scale: Unsupervised classifier-free guidance scale.
        remasking: Remasking strategy. 'low_confidence' or 'random'.
        mask_id: The toke id of [MASK] is 126336.
    '''
    x = torch.full((1, prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()

    prompt_index = (x != mask_id)

    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length

    assert steps % num_blocks == 0
    steps = steps // num_blocks

    # 前steps步去噪过程
    last_global_logits = None
    for num_block in range(num_blocks):
        block_mask_index = (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 1) * block_length:] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps)
        for i in range(steps):
            mask_index = (x == mask_id)
            if cfg_scale > 0.:
                un_x = x.clone()
                un_x[prompt_index] = mask_id
                x_ = torch.cat([x, un_x], dim=0)
                logits = model(x_).logits
                logits, un_logits = torch.chunk(logits, 2, dim=0)
                logits = un_logits + (cfg_scale + 1) * (logits - un_logits)
            else:
                logits = model(x).logits
            # if i % 8 == 0:
            #     tokens_semantic_res = []
            #     for token_index in range(x.shape[1]):
            #         tokens_semantic_res+=tokenizer.batch_decode(x[:,token_index])

            #     save_list_to_pickle(tokens_semantic_res, '/home/tangzixuan.8/Generative_recall/attention_score/temp/tokens.pkl')
            #     rename_folder_simple("/home/tangzixuan.8/Generative_recall/attention_score/temp", f"/home/tangzixuan.8/Generative_recall/attention_score/step_{i}")

            x.argmax(-1)
            logits.argmax(-1)
            last_global_logits = logits
            logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
            x0 = torch.argmax(logits_with_noise, dim=-1) # b, l

            if remasking == 'low_confidence':
                p = F.softmax(logits, dim=-1)
                x0_p = torch.squeeze(
                    torch.gather(p, dim=-1, index=torch.unsqueeze(x0, -1)), -1) # b, l
            elif remasking == 'random':
                x0_p = torch.rand((x0.shape[0], x0.shape[1]), device=x0.device)
            else:
                raise NotImplementedError(remasking)

            x0_p[:, prompt.shape[1] + (num_block + 1) * block_length:] = -np.inf
            x0 = torch.where(mask_index, x0, x)
            confidence1 = torch.where(mask_index, x0_p, -np.inf)
            confidence = torch.where(mask_index, x0_p, -np.inf)

            transfer_index = torch.zeros_like(x0, dtype=torch.bool, device=x0.device)
            for j in range(confidence.shape[0]):
                topk_logits, select_index = torch.topk(confidence[j], k=num_transfer_tokens[j, i])
                # _, select_index = torch.topk(confidence[j], k=min(i+1, confidence.shape[1]))
                transfer_index[j, select_index] = True
            x[transfer_index] = x0[transfer_index]
    return x, None

def test(model, device, tokenizer, prompt):
    # Add special tokens for the Instruct model. The Base model does not require the following two lines.
    m = [{"role": "user", "content": prompt}, ]
    prompt = tokenizer.apply_chat_template(m, add_generation_prompt=True, tokenize=False)
    input_ids = tokenizer(prompt)['input_ids']
    input_ids = torch.tensor(input_ids).to(device).unsqueeze(0)
    res = []
    for ind in range(input_ids.shape[1]):
        res += tokenizer.batch_decode(input_ids[:,ind])
    out, out_revise = generate(model, input_ids, steps=32, gen_length=32, block_length=32, post_step_num=32, temperature=0., cfg_scale=0., remasking='low_confidence', tokenizer = tokenizer)
    print(tokenizer.batch_decode(out[:, input_ids.shape[1]:], skip_special_tokens=True)[0])
    



def main():
    device = 'cuda'
    model = AutoModel.from_pretrained('/home/tangzixuan.8/Generative_recall/LLaDA_weight', trust_remote_code=True, torch_dtype=torch.bfloat16).to(device).eval()
    tokenizer = AutoTokenizer.from_pretrained('/home/tangzixuan.8/Generative_recall/LLaDA_weight', trust_remote_code=True)
    test(model, device, tokenizer, "There are 239 bags of potato chips in the store. After selling some, 21 bags remain. Later, 187 bags are shipped in. How many bags of potato chips are in the store now? Answer: This problem can be solved using addition and subtraction. After selling some, 21 bags remain, and then 187 bags are added, so there are 187 + 21 = 208 bags in total.")
    


if __name__ == '__main__':
    main()
