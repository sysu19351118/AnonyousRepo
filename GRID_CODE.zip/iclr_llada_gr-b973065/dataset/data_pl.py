import json
import pandas as pd
import numpy as np
from collections import defaultdict
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import random
from transformers import BertTokenizer, BertModel
import pdb
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR
import os
import pickle

import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from typing import Dict, List, Tuple, Optional, Any
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
import yaml

import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from typing import Dict, List, Tuple, Optional, Any
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
import yaml
import json
import pandas as pd
import numpy as np
from collections import defaultdict
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import random
from transformers import BertTokenizer, BertModel
import pdb
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR
from pytorch_lightning.callbacks import ModelCheckpoint


# 设置随机种子保证可重现
SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)
random.seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)



# 读取数据
def load_data(file_path, sample_frac=1.0):
    reviews = []
    with open(file_path, 'r') as f:
        for line in f:
            reviews.append(json.loads(line))
    print('用户数据load完成')
    df = pd.DataFrame(reviews)
    if sample_frac < 1.0:
        df = df.sample(frac=sample_frac, random_state=SEED)
    return df

def load_item_data(file_path):
    items = []
    with open(file_path, 'r') as f:
        for line in f:
            items.append(json.loads(line))
    item_df = pd.DataFrame(items)
    print('物品数据load完成')
    return item_df



def split_train_test(df, user_hist):
    # 创建测试集：每个用户的最后一个交互
    test_records = []
    for user, items in tqdm(user_hist.items()):
        if len(items) > 0:
            last_item = items[-1]  # 最后一个交互的商品
            # 找到对应的行
            user_df = df[df['reviewerID'] == user]
            # 找到该用户最后一条关于last_item的记录（可能有多个相同商品的记录）
            last_record = user_df[user_df['asin'] == last_item].sort_values('unixReviewTime').iloc[-1]
            test_records.append(last_record)
    
    test_df = pd.DataFrame(test_records)
    

    # 创建训练集：排除测试集中的记录
    # 使用索引来排除测试集记录
    train_df = df.drop(test_df.index)
    
    return train_df, test_df


# 在你的load_feature函数中使用：
def load_feature(config, user_json_path, item_json_path):
    


    df = load_data(user_json_path, sample_frac=1)  
    item_df = load_item_data(item_json_path)
    # 转换时间戳
    df['unixReviewTime'] = pd.to_numeric(df['unixReviewTime'])
    df['reviewTime'] = pd.to_datetime(df['unixReviewTime'], unit='s')

    # 计算每个用户的交互次数
    user_interaction_count = df.groupby('reviewerID').size()

    # 筛选出交互次数 >= 3 的用户
    valid_users = user_interaction_count[user_interaction_count >= 20].index

    # 过滤df，只保留有效用户的记录
    df = df[df['reviewerID'].isin(valid_users)].copy()
    item_df = item_df[item_df['asin'].isin(df['asin'].unique())]

    # 重新构建用户历史序列（基于过滤后的df）
    user_hist = df.groupby('reviewerID').apply(
        lambda x: x.sort_values('unixReviewTime')['asin'].tolist()
    ).to_dict()

    # 划分训练集和测试集
    

    # 缓存路径
    cache_dir = config['data']['cache_path']
    train_cache = os.path.join(cache_dir, "train_df.pkl")
    test_cache = os.path.join(cache_dir, "test_df.pkl")

    # 检查缓存是否存在
    if os.path.exists(train_cache) and os.path.exists(test_cache):
        print("从缓存加载数据...")
        with open(train_cache, 'rb') as f:
            train_df = pickle.load(f)
        with open(test_cache, 'rb') as f:
            test_df = pickle.load(f)
    else:
        print("缓存不存在，创建数据并保存...")
        train_df, test_df = split_train_test(df, user_hist)
        
        # 确保目录存在
        os.makedirs(cache_dir, exist_ok=True)
        
        # 保存到缓存
        with open(train_cache, 'wb') as f:
            pickle.dump(train_df, f)
        with open(test_cache, 'wb') as f:
            pickle.dump(test_df, f)
        print("数据已保存到缓存")
    
    # 创建商品ID到索引的映射（使用完整df的商品集合）
    item_ids = np.unique(np.concatenate([df['asin'].unique(), item_df['asin'].unique()]))
    item2idx = {item: idx for idx, item in enumerate(item_ids)}
    num_items = len(item2idx)

    # 统计item的频次（基于训练集）
    freq = [0] * len(item_ids)
    for item_id in train_df['asin']:
        if item_id in item2idx:
            idx = item2idx[item_id]
            freq[idx] += 1

    # 创建商品品牌到索引的映射
    brand_ids = item_df['brand'].unique()
    brand2idx = {brand: idx for idx, brand in enumerate(brand_ids)}
    num_brands = len(brand2idx)

    # 创建用户ID到索引的映射
    user_ids = df['reviewerID'].unique()
    user2idx = {user: idx for idx, user in enumerate(user_ids)}
    num_users = len(user2idx)

    # 商品价格表
    item_price = {}
    for _, row in item_df.iterrows():
        price_str = row['price']
        try:
            if "$" in price_str:
                item_price[row['asin']] = float(price_str.replace("$", "").replace(",","")) if price_str != '' else 0.0
            else:
                item_price[row['asin']] = 0.0
        except:
            item_price[row['asin']] = 0.0
    
    max_price = max(item_price.values()) if item_price else 1
    for item, price in item_price.items():
        if price == 0.0:
            item_price[item] = int((np.log(max_price) + 1))
        else:
            item_price[item] = int((np.log(price)))


    
    return df, item_df, user_hist, user2idx, item2idx, brand2idx, item_price, freq, train_df, test_df



class BeautyDataset(Dataset):
    def __init__(self, config, df, user_hist, user2idx, item2idx, brand2idx, item_info_df, item_price, item_freq, seq_max_len=50):
        self.df = df
        self.user_hist = user_hist
        self.user2idx = user2idx
        self.item2idx = item2idx
        self.seq_max_len = seq_max_len
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.item_info_df = item_info_df
        self.brand2idx = brand2idx
        self.item_price = item_price
        self.max_price = max(item_price.values())
        self.neg_sample_num = config['train']['neg_sample_num']
        alpha = 0.5  # 经典的α值，可以调整
        self.item_weights = np.array([item_freq[i] ** alpha for i in range(len(self.item2idx))])
        self.item_weights = self.item_weights / self.item_weights.sum()  # 归一化

        # 统计item id对不上的数量
        self.missing_item_count = 0
        self.wrong_price_count = 0
        

    def __len__(self):
        return len(self.df)

    def price_to_float(self, price_str):
        try:
            if "$" in price_str:
                return float(price_str.replace("$", "").replace(",","")) if price_str != '' else 0.0
            else:
                self.wrong_price_count += 1
                return 0.0
        except:
            self.wrong_price_count += 1
            return 0.0
    
    def __getitem__(self, idx):
        record = self.df.iloc[idx]

        # 用户侧信息
        user_info = {}
        user = record['reviewerID']
        
        item = record['asin'] # 用户当前交互的商品
        
        # 用户历史序列
        user_history = self.user_hist.get(user, [])
        # 排除当前商品
        try:
            cutoff_index = user_history.index(item)
            filtered_history = user_history[:cutoff_index]
        except ValueError:
            filtered_history = user_history.copy()

        # 截取最后 seq_max_len 个商品
        filtered_history = filtered_history[-self.seq_max_len:]

        # 创建mask
        actual_length = len(filtered_history)
        mask = [1] * actual_length + [0] * (self.seq_max_len - actual_length)

        # 如果需要前面填充
        filtered_history = filtered_history + [0] * (self.seq_max_len - actual_length) 

        user_history = filtered_history

        
        # 转换为索引
        user_idx = self.user2idx[user]

        # 处理用户历史行为
        item_idx = self.item2idx[item]
        hist_idx = []
        hist_idx_mask = []
        for it in user_history:
            if it in self.item2idx:
                hist_idx.append(self.item2idx[it])
                hist_idx_mask.append(1)
            else:
                hist_idx.append(0)
                hist_idx_mask.append(0)

        user_info["user_idx"] = user_idx
        user_info["hist_idx"] = hist_idx
        user_info["hist_idx_mask"] = hist_idx_mask


        if np.array(self.item_info_df['asin']==item).sum() == 0:
            self.missing_item_count += 1
            return self.__getitem__(random.randint(0, len(self.df) - 1))
 
        
        
        # 正样本信息
        pos_item_idx = item_idx
        # 
        pos_item_info = self.item_info_df[self.item_info_df['asin']==item]
        try:
            pos_brand = pos_item_info['brand'].values[0]
        except:
            pdb.set_trace()
        pos_brand_idx = self.brand2idx.get(pos_brand, 0)
        pos_also_buy = pos_item_info['also_buy'].values[0]

        pos_also_buy_idx = [self.item2idx[it] for it in pos_also_buy if it in self.item2idx]
        pos_price = self.item_price.get(item, self.max_price)

        pos_title = pos_item_info['title'].values[0]
        pos_title_token = self.tokenizer(pos_title, padding='max_length', truncation=True, max_length=20, return_tensors='pt')
        pos_description = pos_item_info['description'].values[0] if pos_item_info['description'].values[0] != [] else '""'
        if len(pos_description) > 1:
            pos_description = " ".join(pos_description)
        pos_description_token = self.tokenizer(pos_description, padding='max_length', truncation=True, max_length=200, return_tensors='pt')
        pos_item_info = {
            'pos_item_idx': pos_item_idx,
            'pos_brand_idx': pos_brand_idx,
            'pos_also_buy_idx': pos_also_buy_idx,
            'pos_price': pos_price,
            'pos_title_token': pos_title_token,
            'pos_description_token': pos_description_token
        }

        # 负样本采样 选取两个负样本
        neg_item_idx_ = []
        neg_brand_idx_ = []
        neg_also_buy_idx_ = []
        neg_price_ = []
        neg_title_token_ = []
        neg_description_token_ = []
        for i in range(self.neg_sample_num):
            neg_item_idx = pos_item_idx
            while neg_item_idx == pos_item_idx:
                neg_item_idx = np.random.choice(
                    len(self.item2idx), 
                    p=self.item_weights
                )
            neg_item_idx_.append(neg_item_idx)

            # 负样本其他信息
            neg_item_info = self.item_info_df[self.item_info_df['asin']==list(self.item2idx.keys())[neg_item_idx]]

            if len(neg_item_info) == 0:
                neg_brand_idx = 0
                neg_also_buy_idx = []
                neg_price = self.max_price
                neg_title_token = self.tokenizer('""', padding='max_length', truncation=True, max_length=20, return_tensors='pt')
                neg_description_token = self.tokenizer("", padding='max_length', truncation=True, max_length=50, return_tensors='pt')
            else:
                neg_brand = neg_item_info['brand'].values[0]
                neg_brand_idx = self.brand2idx.get(neg_brand, 0)
                neg_also_buy = neg_item_info['also_buy'].values[0]
                neg_also_buy_idx = [self.item2idx[it] for it in neg_also_buy if it in self.item2idx]
                a = neg_item_info['price'].values[0]
                neg_price = self.item_price.get(neg_item_info['asin'].values[0], self.max_price)
                neg_title = neg_item_info['title'].values[0]
                neg_title_token = self.tokenizer(neg_title, padding='max_length', truncation=True, max_length=20, return_tensors='pt')
                neg_description = neg_item_info['description'].values[0] if neg_item_info['description'].values[0] != [] else '""'
                if len(neg_description) > 1:
                    neg_description = " ".join(neg_description)
                neg_description_token = self.tokenizer(neg_description, padding='max_length', truncation=True, max_length=50, return_tensors='pt')
            neg_brand_idx_.append(neg_brand_idx)
            neg_also_buy_idx_.append(neg_also_buy_idx)
            neg_price_.append(neg_price)
            neg_title_token_.append(neg_title_token)
            neg_description_token_.append(neg_description_token)

        neg_item_info = {
            'neg_item_idx': neg_item_idx_,
            'neg_brand_idx': neg_brand_idx_,
            'neg_also_buy_idx': neg_also_buy_idx_,
            'neg_price': neg_price_,
            'neg_title_token': neg_title_token_,
            'neg_description_token': neg_description_token_
        }
        
        return user_info, pos_item_info, neg_item_info

    def collate_fn(self, batch):
        batch_user_idx = []
        batch_hist_idx = []
        batch_hist_idx_mask = []
        
        batch_pos_item_idx = []
        batch_pos_brand_idx = []
        batch_pos_also_buy_idx = []
        batch_pos_price = []
        batch_pos_title_input_ids = []
        batch_pos_title_attention_mask = []
        batch_pos_description_input_ids = []
        batch_pos_description_attention_mask = []

        batch_neg_item_idx = []
        batch_neg_brand_idx = []
        batch_neg_also_buy_idx = []
        batch_neg_price = []
        batch_neg_title_input_ids = []
        batch_neg_title_attention_mask = []
        batch_neg_description_input_ids = []
        batch_neg_description_attention_mask = []

        for usr_info, pos_item_info, neg_item_info in batch:
            # 用户信息
            batch_user_idx.append(usr_info['user_idx'])
            batch_hist_idx.append(usr_info['hist_idx'])
            batch_hist_idx_mask.append(usr_info['hist_idx_mask'])

            # 正样本信息
            batch_pos_item_idx.append(pos_item_info['pos_item_idx'])
            
            batch_pos_brand_idx.append(pos_item_info['pos_brand_idx'])
            # batch_pos_also_buy_idx.append(pos_item_info['pos_also_buy_idx'])
            batch_pos_price.append(pos_item_info['pos_price'])
            batch_pos_title_input_ids.append(pos_item_info['pos_title_token']['input_ids'].squeeze(0))
            batch_pos_title_attention_mask.append(pos_item_info['pos_title_token']['attention_mask'].squeeze(0))
            batch_pos_description_input_ids.append(pos_item_info['pos_description_token']['input_ids'].squeeze(0))
            batch_pos_description_attention_mask.append(pos_item_info['pos_description_token']['attention_mask'].squeeze(0))

            # 负样本信息
            for i in range(self.neg_sample_num):
                neg_item_info_single = {
                    'neg_item_idx': neg_item_info['neg_item_idx'][i],
                    'neg_brand_idx': neg_item_info['neg_brand_idx'][i],
                    # 'neg_also_buy_idx': neg_item_info['neg_also_buy_idx'][i],
                    'neg_price': neg_item_info['neg_price'][i],
                    'neg_title_token': neg_item_info['neg_title_token'][i],
                    'neg_description_token': neg_item_info['neg_description_token'][i]
                }

                batch_neg_item_idx.append(neg_item_info_single['neg_item_idx'])
                batch_neg_brand_idx.append(neg_item_info_single['neg_brand_idx'])
                # batch_neg_also_buy_idx.append(neg_item_info_single['neg_also_buy_idx'])
                batch_neg_price.append(neg_item_info_single['neg_price'])
                batch_neg_title_input_ids.append(neg_item_info_single['neg_title_token']['input_ids'].squeeze(0))
                batch_neg_title_attention_mask.append(neg_item_info_single['neg_title_token']['attention_mask'].squeeze(0))
                batch_neg_description_input_ids.append(neg_item_info_single['neg_description_token']['input_ids'].squeeze(0))
                batch_neg_description_attention_mask.append(neg_item_info_single['neg_description_token']['attention_mask'].squeeze(0))
                
            # batch_neg_item_idx.append(neg_item_info['neg_item_idx'])
            # batch_neg_brand_idx.append(neg_item_info['neg_brand_idx'])
            # batch_neg_also_buy_idx.append(neg_item_info['neg_also_buy_idx'])
            # batch_neg_price.append(neg_item_info['neg_price'])
            # batch_neg_title_input_ids.append(neg_item_info['neg_title_token']['input_ids'].squeeze(0))
            # batch_neg_title_attention_mask.append(neg_item_info['neg_title_token']['attention_mask'].squeeze(0))
            # batch_neg_description_input_ids.append(neg_item_info['neg_description_token']['input_ids'].squeeze(0))
            # batch_neg_description_attention_mask.append(neg_item_info['neg_description_token']['attention_mask'].squeeze(0))

        # 对齐user history长度
        max_hist_len = max([len(h) for h in batch_hist_idx])
        batch_hist_idx = [([0] * (max_hist_len - len(h)) + h) if len(h) < max_hist_len else h for h in batch_hist_idx]

        batch_user_idx = torch.tensor(batch_user_idx, dtype=torch.long)
        batch_hist_idx = torch.tensor(batch_hist_idx, dtype=torch.long)
        batch_hist_idx_mask = torch.tensor(batch_hist_idx_mask, dtype=torch.long)
        batch_pos_item_idx = torch.tensor(batch_pos_item_idx, dtype=torch.long)
        batch_pos_brand_idx = torch.tensor(batch_pos_brand_idx, dtype=torch.long)
        batch_pos_price = torch.tensor(batch_pos_price, dtype=torch.long)
        batch_pos_title_input_ids = torch.stack(batch_pos_title_input_ids)
        batch_pos_title_attention_mask = torch.stack(batch_pos_title_attention_mask)
        batch_pos_description_input_ids = torch.stack(batch_pos_description_input_ids)
        batch_pos_description_attention_mask = torch.stack(batch_pos_description_attention_mask)  
        

        batch_neg_item_idx = torch.tensor(batch_neg_item_idx, dtype=torch.long)
        batch_neg_brand_idx = torch.tensor(batch_neg_brand_idx, dtype=torch.long)
        batch_neg_price = torch.tensor(batch_neg_price, dtype=torch.long)
        batch_neg_title_input_ids = torch.stack(batch_neg_title_input_ids)
        batch_neg_title_attention_mask = torch.stack(batch_neg_title_attention_mask)
        batch_neg_description_input_ids = torch.stack(batch_neg_description_input_ids)
        batch_neg_description_attention_mask = torch.stack(batch_neg_description_attention_mask)

        user_feature = {
            'user_idx': batch_user_idx,
            'hist_idx': batch_hist_idx,
            'hist_idx_mask': batch_hist_idx_mask
        }
        pos_item_feature = {
            'pos_item_idx': batch_pos_item_idx,
            'pos_brand_idx': batch_pos_brand_idx,
            # 'pos_also_buy_idx': batch_pos_also_buy_idx,
            'pos_price': batch_pos_price,
            'pos_title_input_ids': batch_pos_title_input_ids,
            'pos_title_attention_mask': batch_pos_title_attention_mask,
            'pos_description_input_ids': batch_pos_description_input_ids,
            'pos_description_attention_mask': batch_pos_description_attention_mask
        }
        neg_item_feature = {
            'neg_item_idx': batch_neg_item_idx,
            'neg_brand_idx': batch_neg_brand_idx,
            # 'neg_also_buy_idx': batch_neg_also_buy_idx,
            'neg_price': batch_neg_price,
            'neg_title_input_ids': batch_neg_title_input_ids,
            'neg_title_attention_mask': batch_neg_title_attention_mask,
            'neg_description_input_ids': batch_neg_description_input_ids,
            'neg_description_attention_mask': batch_neg_description_attention_mask
        }
        return user_feature, pos_item_feature, neg_item_feature


# 示例数据模块
class DualTowerDataModule(pl.LightningDataModule):
    def __init__(
        self,
        config: Dict[str, Any] = None,
        batch_size: int = 256,
        num_workers: int = 0,
        user_json_path: str = '/mnt/data2/zzixuantang/ICLR/data/amazon-toy/Toys_and_Games.json',
        item_json_path: str = '/mnt/data2/zzixuantang/ICLR/data/amazon-toy/meta_Toys_and_Games.json',
        optimizer: str = "adam",
        scheduler: str = "step",
        scheduler_params: Optional[Dict[str, Any]] = 'cosine'
    ):
        super().__init__()
        self.config = config
        self.batch_size = batch_size
        self.num_workers = num_workers
        df, item_df, user_hist, user2idx, item2idx, brand2idx, item_price, item_freq, self.train_df, self.test_df  = load_feature(config, user_json_path, item_json_path)
        self.df = df
        self.item_df = item_df
        self.user_hist = user_hist  
        self.user2idx = user2idx
        self.item2idx = item2idx
        self.brand2idx = brand2idx
        self.item_price = item_price
        self.item_freq = item_freq

    
    def prepare_data(self):
        """下载或准备数据"""
        pass
    
    def setup(self, stage: Optional[str] = None):
        """设置数据集"""
        pass
    
    def train_dataloader(self):
        """训练数据加载器"""
        train_dataset = BeautyDataset(self.config, self.train_df, self.user_hist, self.user2idx, self.item2idx, self.brand2idx, self.item_df, self.item_price, self.item_freq)
        return DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers, collate_fn=train_dataset.collate_fn)
    
    def val_dataloader(self):
        """验证数据加载器"""
        test_dataset = BeautyDataset(self.config, self.test_df, self.user_hist, self.user2idx, self.item2idx, self.brand2idx, self.item_df, self.item_price, self.item_freq)
        return DataLoader(test_dataset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers, collate_fn=test_dataset.collate_fn)
    
    def test_dataloader(self):
        """测试数据加载器"""
        test_dataset = BeautyDataset(self.config, self.test_df, self.user_hist, self.user2idx, self.item2idx, self.brand2idx, self.item_df, self.item_price, self.item_freq)
        return DataLoader(test_dataset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers, collate_fn=test_dataset.collate_fn)


def load_config(config_path):
    """加载YAML配置文件"""
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config

if __name__ == "__main__":
    config = load_config('/home/tangzixuan.8/Generative_recall/generative_recall_rank/config/config.yaml')
    data_module = DualTowerDataModule(config, batch_size=config['train']['batch_size'], num_workers=config['train']['num_workers'], user_json_path = config['data']['user_data_path'], item_json_path = config['data']['item_data_path'])